import 'package:cloud_firestore/cloud_firestore.dart';

class ListingModel {
  /// REQUIRED
  String id;

  /// Author
  String authorID;
  String authorName;
  String authorProfilePic;

  /// Category
  String categoryID;
  String categoryPhoto;
  String categoryTitle;

  /// Core
  int createdAt;
  String title;
  String description;
  String place;
  double latitude;
  double longitude;

  /// Media
  String photo; // PRIMARY image (used everywhere)
  List<String> photos;
  List<String> videos;

  /// Optional
  String price;
  String phone;
  String email;
  String website;
  String openingHours;

  /// Filters / meta
  Map<String, dynamic> filters;
  bool isApproved;

  /// Reviews
  num reviewsCount;
  num reviewsSum;

  /// Region
  String countryCode;

  /// UI-only
  bool isFav = false;

  ListingModel({
    this.id = '',
    this.authorID = '',
    this.authorName = '',
    this.authorProfilePic = '',
    this.categoryID = '',
    this.categoryPhoto = '',
    this.categoryTitle = '',
    int? createdAt,
    this.title = '',
    this.description = '',
    this.place = '',
    this.latitude = 0,
    this.longitude = 0,
    this.photo = '',
    this.photos = const [],
    this.videos = const [],
    this.price = '',
    this.phone = '',
    this.email = '',
    this.website = '',
    this.openingHours = '',
    this.filters = const {},
    this.isApproved = false,
    this.reviewsCount = 0,
    this.reviewsSum = 0,
    this.countryCode = '',
  }) : createdAt = createdAt ?? Timestamp.now().seconds;

  factory ListingModel.fromJson(Map<String, dynamic> json) {
    return ListingModel(
      id: json['id'] ?? '',
      authorID: json['authorID'] ?? '',
      authorName: json['authorName'] ?? '',
      authorProfilePic: json['authorProfilePic'] ?? '',
      categoryID: json['categoryID'] ?? '',
      categoryPhoto: json['categoryPhoto'] ?? '',
      categoryTitle: json['categoryTitle'] ?? '',
      createdAt: json['createdAt'] is Timestamp
          ? (json['createdAt'] as Timestamp).seconds
          : (json['createdAt'] ?? Timestamp.now().seconds),
      title: json['title'] ?? '',
      description: json['description'] ?? '',
      place: json['place'] ?? '',
      latitude: (json['latitude'] ?? 0).toDouble(),
      longitude: (json['longitude'] ?? 0).toDouble(),
      photo: json['photo'] ?? '',
      photos: List<String>.from(json['photos'] ?? []),
      videos: List<String>.from(json['videos'] ?? []),
      price: json['price'] ?? '',
      phone: json['phone'] ?? '',
      email: json['email'] ?? '',
      website: json['website'] ?? '',
      openingHours: json['openingHours'] ?? '',
      filters: Map<String, dynamic>.from(json['filters'] ?? {}),
      isApproved: json['isApproved'] ?? false,
      reviewsCount: json['reviewsCount'] ?? 0,
      reviewsSum: json['reviewsSum'] ?? 0,
      countryCode: json['countryCode'] ?? '',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'authorID': authorID,
      'authorName': authorName,
      'authorProfilePic': authorProfilePic,
      'categoryID': categoryID,
      'categoryPhoto': categoryPhoto,
      'categoryTitle': categoryTitle,
      'createdAt': createdAt,
      'title': title,
      'description': description,
      'place': place,
      'latitude': latitude,
      'longitude': longitude,
      'photo': photo,
      'photos': photos,
      'videos': videos,
      'price': price,
      'phone': phone,
      'email': email,
      'website': website,
      'openingHours': openingHours,
      'filters': filters,
      'isApproved': isApproved,
      'reviewsCount': reviewsCount,
      'reviewsSum': reviewsSum,
      'countryCode': countryCode,
    };
  }
}
