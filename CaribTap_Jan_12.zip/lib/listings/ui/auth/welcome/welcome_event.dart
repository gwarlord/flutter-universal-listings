part of 'welcome_bloc.dart';

abstract class WelcomeEvent {}

class LoginPressedEvent extends WelcomeEvent {}

class SignupPressedEvent extends WelcomeEvent {}
