import 'dart:io';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:instaflutter/core/ui/loading/loading_cubit.dart';
import 'package:instaflutter/core/utils/ads/ads_utils.dart';
import 'package:instaflutter/core/utils/helper.dart';
import 'package:instaflutter/listings/listings_app_config.dart';
import 'package:instaflutter/listings/listings_module/add_listing/add_listing_screen.dart';
import 'package:instaflutter/listings/listings_module/api/listings_api_manager.dart';
import 'package:instaflutter/listings/listings_module/category_listings/category_listings_screen.dart';
import 'package:instaflutter/listings/listings_module/home/home_bloc.dart';
import 'package:instaflutter/listings/listings_module/listing_details/listing_details_screen.dart';
import 'package:instaflutter/listings/model/categories_model.dart';
import 'package:instaflutter/listings/model/listing_model.dart';
import 'package:instaflutter/listings/model/listings_user.dart';
import 'package:instaflutter/listings/ui/auth/authentication_bloc.dart';
import 'package:instaflutter/listings/ui/profile/api/profile_api_manager.dart';

// ✅ NEW: Caribbean country list util (used for filter UI + labels)
import 'package:instaflutter/listings/utils/caribbean_countries.dart';

class HomeWrapperWidget extends StatelessWidget {
  final ListingsUser currentUser;
  final GlobalKey<HomeScreenState> homeKey;

  const HomeWrapperWidget({
    super.key,
    required this.currentUser,
    required this.homeKey,
  });

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => HomeBloc(
        currentUser: currentUser,
        profileRepository: profileApiManager,
        listingsRepository: listingApiManager,
      ),
      child: HomeScreen(
        currentUser: currentUser,
        key: homeKey,
      ),
    );
  }
}

class HomeScreen extends StatefulWidget {
  final ListingsUser currentUser;

  const HomeScreen({super.key, required this.currentUser});

  @override
  HomeScreenState createState() => HomeScreenState();
}

class HomeScreenState extends State<HomeScreen> {
  List<ListingModel> listings = [];
  List<ListingModel?> listingsWithAds = [];
  List<CategoriesModel> _categories = [];

  bool _showAll = false;
  bool loadingCategories = true;
  bool loadingListings = true;

  late ListingsUser currentUser;

  // Search + category filter
  final TextEditingController _homeSearchController = TextEditingController();
  String _homeQuery = '';
  String? _selectedCategoryTitle; // filter using listing.categoryTitle (safe)
  List<ListingModel> _filteredListings = [];

  // ✅ NEW: Multi-country filter (store ISO alpha-2 codes)
  final Set<String> _selectedCountryCodes = <String>{};

  @override
  void initState() {
    super.initState();
    currentUser = widget.currentUser;
    context.read<HomeBloc>().add(GetCategoriesEvent());
    context.read<HomeBloc>().add(GetListingsEvent());
  }

  @override
  void dispose() {
    _homeSearchController.dispose();
    super.dispose();
  }

  // ✅ NEW helpers
  String _flagEmojiFromCountryCode(String? code) {
    final c = (code ?? '').trim().toUpperCase();
    if (c.length != 2) return '';
    final int first = c.codeUnitAt(0);
    final int second = c.codeUnitAt(1);
    if (first < 65 || first > 90 || second < 65 || second > 90) return '';
    return String.fromCharCodes([first + 127397, second + 127397]);
  }

  String _countryLabel(String? code) {
    final c = (code ?? '').trim().toUpperCase();
    if (c.isEmpty) return '';
    final found = CaribbeanCountries.byCode(c);
    return found?.name ?? c;
  }

  bool get _hasActiveFilters =>
      _homeQuery.trim().isNotEmpty ||
          (_selectedCategoryTitle?.trim().isNotEmpty ?? false) ||
          _selectedCountryCodes.isNotEmpty;

  void _rebuildFiltered() {
    // Use the clean (non-ad) list as the source to filter.
    final source = listings;

    final query = _homeQuery.trim().toLowerCase();
    final selectedCat = _selectedCategoryTitle?.trim().toLowerCase();

    final result = <ListingModel>[];

    for (final l in source) {
      // Category filter
      if (selectedCat != null && selectedCat.isNotEmpty) {
        final catTitle = (l.categoryTitle).toString().trim().toLowerCase();
        if (catTitle != selectedCat) continue;
      }

      // ✅ Country filter (multi-select)
      if (_selectedCountryCodes.isNotEmpty) {
        final lCode = (l.countryCode).toString().trim().toUpperCase();
        if (!_selectedCountryCodes.contains(lCode)) continue;
      }

      // Text filter
      if (query.isNotEmpty) {
        final title = l.title.toString().toLowerCase();
        final place = l.place.toString().toLowerCase();
        final cat = l.categoryTitle.toString().toLowerCase();
        final price = l.price.toString().toLowerCase();

        // includes description
        final desc = (l.description).toString().toLowerCase();

        final matches = title.contains(query) ||
            place.contains(query) ||
            cat.contains(query) ||
            price.contains(query) ||
            desc.contains(query);

        if (!matches) continue;
      }

      result.add(l);
    }

    setState(() {
      _filteredListings = result;
    });
  }

  void _clearFilters() {
    FocusScope.of(context).unfocus();
    setState(() {
      _homeQuery = '';
      _selectedCategoryTitle = null;
      _selectedCountryCodes.clear(); // ✅ NEW
      _homeSearchController.clear();
      _filteredListings = [];
    });
  }

  // ✅ NEW: Bottom sheet multi-select for countries
  Future<void> _openCountryFilterSheet() async {
    final temp = Set<String>.from(_selectedCountryCodes);

    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        'Filter by Country'.tr(),
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                    TextButton(
                      onPressed: () {
                        temp.clear();
                        (ctx as Element).markNeedsBuild();
                      },
                      child: Text('Clear'.tr()),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Flexible(
                  child: ListView.builder(
                    shrinkWrap: true,
                    itemCount: CaribbeanCountries.all.length,
                    itemBuilder: (context, index) {
                      final c = CaribbeanCountries.all[index];
                      final flag = _flagEmojiFromCountryCode(c.code);
                      final selected = temp.contains(c.code);

                      return CheckboxListTile(
                        value: selected,
                        onChanged: (v) {
                          if (v == true) {
                            temp.add(c.code);
                          } else {
                            temp.remove(c.code);
                          }
                          (ctx as Element).markNeedsBuild();
                        },
                        title: Text('${flag.isNotEmpty ? '$flag  ' : ''}${c.name}'),
                        subtitle: Text(c.code),
                        controlAffinity: ListTileControlAffinity.leading,
                        dense: true,
                      );
                    },
                  ),
                ),
                const SizedBox(height: 10),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.pop(ctx);
                      setState(() {
                        _selectedCountryCodes
                          ..clear()
                          ..addAll(temp);
                      });
                      _rebuildFiltered();
                    },
                    child: Text('Apply'.tr()),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final bool dark = isDarkMode(context);

    return Scaffold(
      body: RefreshIndicator(
        onRefresh: () async {
          _clearFilters();
          context.read<HomeBloc>().add(LoadingEvent());
          context.read<HomeBloc>().add(GetCategoriesEvent());
          context.read<HomeBloc>().add(GetListingsEvent());
        },
        child: BlocConsumer<HomeBloc, HomeState>(
          listener: (context, state) {
            if (state is CategoriesListState) {
              loadingCategories = false;
              _categories = state.categories;
              // no filter rebuild needed here
            } else if (state is ListingsListState) {
              context.read<LoadingCubit>().hideLoading();
              loadingListings = false;

              listingsWithAds = state.listingsWithAds;
              final tempList = [...listingsWithAds]..removeWhere((e) => e == null);
              listings = [...tempList.cast<ListingModel>()];

              // If filters are active, rebuild filtered list from fresh data
              if (_hasActiveFilters) {
                _rebuildFiltered();
              }
            } else if (state is LoadingCategoriesState) {
              loadingCategories = true;
            } else if (state is LoadingListingsState) {
              loadingListings = true;
            } else if (state is ToggleShowAllState) {
              _showAll = !_showAll;
            } else if (state is ListingFavToggleState) {
              currentUser = state.updatedUser;
              context.read<AuthenticationBloc>().user = state.updatedUser;

              final idx = listings.indexWhere((e) => e.id == state.listing.id);
              if (idx != -1) {
                listings[idx].isFav = state.listing.isFav;
              }
              final idx2 = listingsWithAds.indexWhere((e) => e?.id == state.listing.id);
              if (idx2 != -1) {
                listingsWithAds[idx2]?.isFav = state.listing.isFav;
              }

              // Keep filtered results in sync too
              final idx3 = _filteredListings.indexWhere((e) => e.id == state.listing.id);
              if (idx3 != -1) {
                _filteredListings[idx3].isFav = state.listing.isFav;
              }
            } else if (state is LoadingState) {
              _showAll = false;
              loadingListings = true;
              loadingCategories = true;
            }
          },
          builder: (context, state) {
            if (loadingCategories && loadingListings) {
              return const Center(child: CircularProgressIndicator.adaptive());
            }

            // Decide what we show in the grid
            final bool showFilteredGrid = _hasActiveFilters;
            final List<ListingModel> gridListings =
            showFilteredGrid ? _filteredListings : listings;

            return Padding(
              padding: const EdgeInsets.all(16.0),
              child: CustomScrollView(
                keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
                slivers: [
                  // Search Bar
                  SliverToBoxAdapter(
                    child: TextField(
                      controller: _homeSearchController,
                      onChanged: (v) {
                        _homeQuery = v;
                        _rebuildFiltered();
                      },
                      textAlignVertical: TextAlignVertical.center,
                      textInputAction: TextInputAction.search,
                      textCapitalization: TextCapitalization.words,
                      decoration: InputDecoration(
                        contentPadding: const EdgeInsets.all(12),
                        isDense: true,
                        fillColor:
                        dark ? Colors.grey.shade800 : Colors.grey.shade200,
                        filled: true,
                        focusedBorder: const OutlineInputBorder(
                          borderRadius: BorderRadius.all(Radius.circular(360)),
                          borderSide: BorderSide(style: BorderStyle.none),
                        ),
                        enabledBorder: const OutlineInputBorder(
                          borderRadius: BorderRadius.all(Radius.circular(360)),
                          borderSide: BorderSide(style: BorderStyle.none),
                        ),
                        hintText: 'Search for listings'.tr(),
                        prefixIcon: const Icon(Icons.search, size: 20),
                        suffixIcon: (_homeQuery.trim().isNotEmpty)
                            ? IconButton(
                          iconSize: 20,
                          icon: const Icon(Icons.close),
                          onPressed: () {
                            _homeSearchController.clear();
                            _homeQuery = '';
                            _rebuildFiltered();
                          },
                        )
                            : null,
                      ),
                    ),
                  ),

                  const SliverToBoxAdapter(child: SizedBox(height: 16)),

                  SliverToBoxAdapter(
                    child: Row(
                      children: [
                        Expanded(
                          child: Text(
                            'Categories'.tr(),
                            style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 22,
                            ),
                          ),
                        ),
                        if (_hasActiveFilters)
                          TextButton(
                            onPressed: _clearFilters,
                            child: Text(
                              'Clear'.tr(),
                              style: TextStyle(color: Color(colorPrimary)),
                            ),
                          ),
                      ],
                    ),
                  ),
                  const SliverToBoxAdapter(child: SizedBox(height: 8)),

                  if (loadingCategories)
                    const SliverToBoxAdapter(
                      child: Padding(
                        padding: EdgeInsets.all(16.0),
                        child: Center(
                          child: CircularProgressIndicator.adaptive(),
                        ),
                      ),
                    ),

                  if (_categories.isEmpty)
                    SliverToBoxAdapter(
                      child: Center(
                        child: showEmptyState(
                          'No Categories'.tr(),
                          'All Categories will be shown here once added by the admin.'.tr(),
                        ),
                      ),
                    ),

                  // Category filter chips
                  if (_categories.isNotEmpty)
                    SliverToBoxAdapter(
                      child: SizedBox(
                        height: 44,
                        child: ListView(
                          scrollDirection: Axis.horizontal,
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(right: 8.0),
                              child: ChoiceChip(
                                label: Text('All'.tr()),
                                selected: _selectedCategoryTitle == null,
                                onSelected: (_) {
                                  setState(() => _selectedCategoryTitle = null);
                                  _rebuildFiltered();
                                },
                              ),
                            ),
                            ..._categories.map((c) {
                              final selected = (_selectedCategoryTitle?.toLowerCase() ==
                                  c.title.toLowerCase());
                              return Padding(
                                padding: const EdgeInsets.only(right: 8.0),
                                child: ChoiceChip(
                                  label: Text(c.title),
                                  selected: selected,
                                  onSelected: (_) {
                                    setState(() {
                                      _selectedCategoryTitle = selected ? null : c.title;
                                    });
                                    _rebuildFiltered();
                                  },
                                ),
                              );
                            }).toList(),
                          ],
                        ),
                      ),
                    ),

                  const SliverToBoxAdapter(child: SizedBox(height: 10)),

                  // ✅ NEW: Countries filter bar
                  SliverToBoxAdapter(
                    child: Row(
                      children: [
                        Expanded(
                          child: Text(
                            'Countries'.tr(),
                            style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                            ),
                          ),
                        ),
                        TextButton(
                          onPressed: _openCountryFilterSheet,
                          child: Text(
                            'Select'.tr(),
                            style: TextStyle(color: Color(colorPrimary)),
                          ),
                        ),
                      ],
                    ),
                  ),

                  // ✅ NEW: Selected country chips
                  if (_selectedCountryCodes.isNotEmpty)
                    SliverToBoxAdapter(
                      child: SizedBox(
                        height: 44,
                        child: ListView(
                          scrollDirection: Axis.horizontal,
                          children: _selectedCountryCodes.map((code) {
                            final label = _countryLabel(code);
                            final flag = _flagEmojiFromCountryCode(code);
                            return Padding(
                              padding: const EdgeInsets.only(right: 8.0),
                              child: InputChip(
                                label: Text(
                                  '${flag.isNotEmpty ? '$flag ' : ''}$label',
                                ),
                                onDeleted: () {
                                  setState(() => _selectedCountryCodes.remove(code));
                                  _rebuildFiltered();
                                },
                              ),
                            );
                          }).toList(),
                        ),
                      ),
                    ),

                  const SliverToBoxAdapter(child: SizedBox(height: 10)),

                  // Existing category cards (still navigates)
                  if (_categories.isNotEmpty)
                    SliverToBoxAdapter(
                      child: SizedBox(
                        height: 100,
                        child: ListView.builder(
                          scrollDirection: Axis.horizontal,
                          itemCount: _categories.length,
                          itemBuilder: (context, index) => CategoryHomeCardWidget(
                            currentUser: currentUser,
                            category: _categories[index],
                          ),
                        ),
                      ),
                    ),

                  const SliverToBoxAdapter(child: SizedBox(height: 16)),

                  SliverToBoxAdapter(
                    child: Text(
                      'Listings'.tr(),
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 22,
                      ),
                    ),
                  ),
                  const SliverToBoxAdapter(child: SizedBox(height: 16)),

                  if (loadingListings)
                    const SliverToBoxAdapter(
                      child: Center(
                        child: CircularProgressIndicator.adaptive(),
                      ),
                    ),

                  // Empty state for filtered results
                  if (!loadingListings && _hasActiveFilters && gridListings.isEmpty)
                    SliverToBoxAdapter(
                      child: Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Center(
                          child: showEmptyState(
                            'No Result'.tr(),
                            'No listing matches your search. Try another keyword or category.'.tr(),
                            buttonTitle: 'Clear Filters'.tr(),
                            isDarkMode: dark,
                            action: _clearFilters,
                            colorPrimary: Color(colorPrimary),
                          ),
                        ),
                      ),
                    ),

                  // Original empty state (no listings at all)
                  if (!loadingListings && !_hasActiveFilters && listingsWithAds.isEmpty)
                    SliverToBoxAdapter(
                      child: Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Center(
                          child: showEmptyState(
                            'No Listings'.tr(),
                            'Add a new listing to show up here once the admin approves it.'.tr(),
                            buttonTitle: 'Add Listing'.tr(),
                            isDarkMode: isDarkMode(context),
                            action: () => push(
                              context,
                              AddListingWrappingWidget(currentUser: currentUser),
                            ),
                            colorPrimary: Color(colorPrimary),
                          ),
                        ),
                      ),
                    ),

                  // GRID:
                  // - If filters active => show filtered list WITHOUT ads
                  // - Else => show original listingsWithAds WITH ads, and showAll behavior
                  if (!loadingListings &&
                      (showFilteredGrid
                          ? gridListings.isNotEmpty
                          : listingsWithAds.isNotEmpty))
                    showFilteredGrid
                        ? SliverGrid(
                      delegate: SliverChildBuilderDelegate(
                            (context, index) {
                          final item = gridListings[index];
                          return ListingHomeCardWidget(
                            currentUser: currentUser,
                            listing: item,
                          );
                        },
                        childCount: gridListings.length,
                      ),
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        mainAxisSpacing: 20,
                        crossAxisSpacing: 16,
                        childAspectRatio: 0.72,
                      ),
                    )
                        : SliverGrid(
                      delegate: SliverChildBuilderDelegate(
                            (context, index) {
                          final item = listingsWithAds[index];
                          return item == null
                              ? AdsUtils.adsContainer()
                              : ListingHomeCardWidget(
                            currentUser: currentUser,
                            listing: item,
                          );
                        },
                        childCount: listingsWithAds.length > 4
                            ? (_showAll ? listingsWithAds.length : 4)
                            : listingsWithAds.length,
                      ),
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        mainAxisSpacing: 20,
                        crossAxisSpacing: 16,
                        childAspectRatio: 0.72,
                      ),
                    ),

                  // Show All only when NOT filtering
                  if (!showFilteredGrid)
                    SliverToBoxAdapter(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 8.0,
                          vertical: 32,
                        ),
                        child: Visibility(
                          visible: !_showAll && listingsWithAds.length > 4,
                          child: TextButton(
                            style: TextButton.styleFrom(
                              padding: const EdgeInsets.symmetric(vertical: 16),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(6),
                                side: BorderSide(color: Color(colorPrimary)),
                              ),
                            ),
                            child: Text(
                              'Show All (${(listings.length - 4) < 0 ? 0 : listings.length - 4})'
                                  .tr(),
                              style: TextStyle(color: Color(colorPrimary)),
                            ),
                            onPressed: () => context.read<HomeBloc>().add(
                              ToggleShowAllEvent(),
                            ),
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}

class CategoryHomeCardWidget extends StatelessWidget {
  final ListingsUser currentUser;
  final CategoriesModel category;

  const CategoryHomeCardWidget({
    super.key,
    required this.currentUser,
    required this.category,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 2.0, right: 2),
      child: GestureDetector(
        onTap: () => push(
          context,
          CategoryListingsWrapperWidget(
            categoryID: category.id,
            categoryName: category.title,
            currentUser: currentUser,
          ),
        ),
        child: SizedBox(
          width: 120,
          height: 120,
          child: Card(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
              side: BorderSide.none,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisSize: MainAxisSize.max,
              children: [
                Expanded(
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(minWidth: 120),
                    child: ClipRRect(
                      borderRadius: const BorderRadius.only(
                        topLeft: Radius.circular(8),
                        topRight: Radius.circular(8),
                      ),
                      child: displayImage(category.photo),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(
                    vertical: 8.0,
                    horizontal: 8,
                  ),
                  child: Center(
                    child: Text(
                      category.title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class ListingHomeCardWidget extends StatefulWidget {
  final ListingModel? listing;
  final ListingsUser currentUser;

  const ListingHomeCardWidget({
    super.key,
    required this.listing,
    required this.currentUser,
  });

  @override
  State<ListingHomeCardWidget> createState() => _ListingHomeCardWidgetState();
}

class _ListingHomeCardWidgetState extends State<ListingHomeCardWidget> {
  @override
  Widget build(BuildContext context) {
    final listing = widget.listing;
    if (listing == null) {
      return AdsUtils.adsContainer();
    }

    final bool dark = isDarkMode(context);

    final double avgRating = (listing.reviewsCount > 0)
        ? (listing.reviewsSum / listing.reviewsCount)
        : 0.0;
    final double safeRating = avgRating.isFinite ? avgRating : 0.0;

    return GestureDetector(
      onLongPress: widget.currentUser.isAdmin
          ? () => _showAdminOptions(listing, context)
          : null,
      onTap: () async {
        final bool? isListingDeleted = await push(
          context,
          ListingDetailsWrappingWidget(
            listing: listing,
            currentUser: widget.currentUser,
          ),
        );
        if (isListingDeleted == true && mounted) {
          context.read<HomeBloc>().add(
            ListingDeletedByUserEvent(listing: listing),
          );
        }
      },
      child: Container(
        decoration: BoxDecoration(
          color: dark ? const Color(0xFF1E1E1E) : Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              blurRadius: 18,
              offset: const Offset(0, 10),
              color: Colors.black.withOpacity(dark ? 0.35 : 0.10),
            ),
          ],
        ),
        clipBehavior: Clip.antiAlias,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            AspectRatio(
              aspectRatio: 16 / 10,
              child: Stack(
                fit: StackFit.expand,
                children: [
                  displayImage(listing.photo),
                  Positioned(
                    left: 0,
                    right: 0,
                    bottom: 0,
                    child: Container(
                      height: 70,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            Colors.transparent,
                            Colors.black.withOpacity(0.55),
                          ],
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    left: 10,
                    bottom: 10,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 6,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.55),
                        borderRadius: BorderRadius.circular(999),
                        border: Border.all(color: Colors.white.withOpacity(0.18)),
                      ),
                      child: Text(
                        (listing.categoryTitle.isNotEmpty)
                            ? listing.categoryTitle
                            : 'Listing'.tr(),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    top: 6,
                    right: 6,
                    child: Material(
                      color: Colors.transparent,
                      child: InkWell(
                        borderRadius: BorderRadius.circular(999),
                        onTap: () => context.read<HomeBloc>().add(
                          ListingFavUpdated(listing: listing),
                        ),
                        child: Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: Colors.black.withOpacity(0.35),
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: Colors.white.withOpacity(0.20),
                            ),
                          ),
                          child: Icon(
                            listing.isFav
                                ? Icons.favorite
                                : Icons.favorite_border,
                            size: 18,
                            color: listing.isFav
                                ? Color(colorPrimary)
                                : Colors.white,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 10, 12, 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    listing.title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 15.5,
                      fontWeight: FontWeight.w700,
                      color: dark ? Colors.white : const Color(0xFF1B1B1B),
                      height: 1.1,
                    ),
                  ),
                  const SizedBox(height: 8),

                  // ✅ UPDATED: place row now shows mini country pill (flag + code)
                  Row(
                    children: [
                      Icon(
                        Icons.place_outlined,
                        size: 16,
                        color: dark ? Colors.white70 : Colors.black54,
                      ),
                      const SizedBox(width: 4),
                      Expanded(
                        child: Text(
                          listing.place,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontSize: 12.5,
                            color: dark ? Colors.white70 : Colors.black54,
                          ),
                        ),
                      ),
                      const SizedBox(width: 6),
                      _CountryPill(countryCode: listing.countryCode),
                    ],
                  ),

                  const SizedBox(height: 10),
                  Row(
                    children: [
                      RatingBar.builder(
                        ignoreGestures: true,
                        minRating: 0,
                        initialRating: safeRating,
                        allowHalfRating: true,
                        itemSize: 18,
                        glow: false,
                        unratedColor: Color(colorPrimary).withOpacity(0.18),
                        itemBuilder: (context, index) => Icon(
                          Icons.star,
                          color: Color(colorPrimary),
                        ),
                        itemCount: 5,
                        onRatingUpdate: (_) {},
                      ),
                      const SizedBox(width: 6),
                      Expanded(
                        child: Text(
                          '${safeRating > 0 ? safeRating.toStringAsFixed(1) : '0.0'} (${listing.reviewsCount})',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontSize: 12.5,
                            fontWeight: FontWeight.w700,
                            color: dark ? Colors.white : Colors.black87,
                          ),
                        ),
                      ),
                      if (listing.price.trim().isNotEmpty) ...[
                        const SizedBox(width: 8),
                        ConstrainedBox(
                          constraints: const BoxConstraints(
                            maxWidth: 90,
                            maxHeight: 28,
                          ),
                          child: Container(
                            alignment: Alignment.center,
                            padding: const EdgeInsets.symmetric(
                              horizontal: 10,
                              vertical: 5,
                            ),
                            decoration: BoxDecoration(
                              color: Color(colorPrimary).withOpacity(0.10),
                              borderRadius: BorderRadius.circular(999),
                              border: Border.all(
                                color: Color(colorPrimary).withOpacity(0.25),
                              ),
                            ),
                            child: Text(
                              listing.price,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                color: Color(colorPrimary),
                                fontWeight: FontWeight.w700,
                                fontSize: 12,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showAdminOptions(ListingModel listing, BuildContext blocContext) =>
      showCupertinoModalPopup(
        context: context,
        builder: (context) => CupertinoActionSheet(
          message: Text(
            listing.title,
            style: const TextStyle(fontSize: 20.0),
          ),
          actions: [
            CupertinoActionSheetAction(
              isDestructiveAction: false,
              onPressed: () async {
                Navigator.pop(context);
                await push(
                  context,
                  EditListingWrappingWidget(
                    currentUser: widget.currentUser,
                    listingToEdit: listing,
                  ),
                );
              },
              child: Text('Edit Listing'.tr()),
            ),
            CupertinoActionSheetAction(
              isDestructiveAction: true,
              onPressed: () async {
                Navigator.pop(context);
                final String title = 'Delete Listing?'.tr();
                final String content =
                'Are you sure you want to remove this listing?'.tr();

                if (Platform.isIOS) {
                  await showCupertinoDialog(
                    context: context,
                    builder: (context) => CupertinoAlertDialog(
                      title: Text(title),
                      content: Text(content),
                      actions: [
                        TextButton(
                          child: Text(
                            'Yes'.tr(),
                            style: const TextStyle(color: Colors.red),
                          ),
                          onPressed: () {
                            Navigator.pop(context);
                            blocContext.read<LoadingCubit>().showLoading(
                              context,
                              'Deleting...'.tr(),
                              false,
                              Color(colorPrimary),
                            );
                            blocContext.read<HomeBloc>().add(
                              ListingDeleteByAdminEvent(listing: listing),
                            );
                          },
                        ),
                        TextButton(
                          child: Text('No'.tr()),
                          onPressed: () => Navigator.pop(context),
                        ),
                      ],
                    ),
                  );
                } else {
                  await showDialog(
                    context: context,
                    builder: (context) => AlertDialog(
                      title: Text(title),
                      content: Text(content),
                      actions: [
                        TextButton(
                          child: Text(
                            'Yes'.tr(),
                            style: const TextStyle(color: Colors.red),
                          ),
                          onPressed: () {
                            Navigator.pop(context);
                            blocContext.read<LoadingCubit>().showLoading(
                              context,
                              'Deleting...'.tr(),
                              false,
                              Color(colorPrimary),
                            );
                            blocContext.read<HomeBloc>().add(
                              ListingDeleteByAdminEvent(listing: listing),
                            );
                          },
                        ),
                        TextButton(
                          child: Text('No'.tr()),
                          onPressed: () => Navigator.pop(context),
                        ),
                      ],
                    ),
                  );
                }
              },
              child: Text('Delete Listing'.tr()),
            ),
          ],
          cancelButton: CupertinoActionSheetAction(
            child: Text('Cancel'.tr()),
            onPressed: () => Navigator.pop(context),
          ),
        ),
      );
}

// ✅ NEW: small country pill (flag + code) used on listing cards
class _CountryPill extends StatelessWidget {
  final String? countryCode;

  const _CountryPill({required this.countryCode});

  String _flag(String? code) {
    final c = (code ?? '').trim().toUpperCase();
    if (c.length != 2) return '';
    final a = c.codeUnitAt(0);
    final b = c.codeUnitAt(1);
    if (a < 65 || a > 90 || b < 65 || b > 90) return '';
    return String.fromCharCodes([a + 127397, b + 127397]);
  }

  @override
  Widget build(BuildContext context) {
    final c = (countryCode ?? '').trim().toUpperCase();
    if (c.isEmpty) return const SizedBox.shrink();

    final flag = _flag(c);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.06),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: Colors.black.withOpacity(0.08)),
      ),
      child: Text(
        '${flag.isNotEmpty ? '$flag ' : ''}$c',
        style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
      ),
    );
  }
}
