import 'dart:async';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:instaflutter/constants.dart';
import 'package:instaflutter/core/ui/full_screen_image_viewer/full_screen_image_viewer.dart';
import 'package:instaflutter/core/utils/helper.dart';
import 'package:instaflutter/listings/model/listing_model.dart';
import 'package:instaflutter/listings/listings_module/listing_details/listing_details_bloc.dart';
import 'package:instaflutter/listings/listings_module/listing_details/listing_details_bloc.dart';
import 'package:instaflutter/listings/listings_module/listing_details/listing_details_bloc.dart';
import 'package:instaflutter/listings/listings_module/listing_details/listing_details_bloc.dart';
import 'package:video_player/video_player.dart';
import 'package:visibility_detector/visibility_detector.dart';

/// ------------------------------------------------------------
/// WRAPPER (DO NOT REMOVE – USED EVERYWHERE IN APP)
/// ------------------------------------------------------------
class ListingDetailsWrappingWidget extends StatelessWidget {
  final ListingModel listing;

  const ListingDetailsWrappingWidget({super.key, required this.listing});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => ListingDetailsBloc(listing: listing),
      child: ListingDetailsScreen(listing: listing),
    );
  }
}

/// ------------------------------------------------------------
/// SCREEN
/// ------------------------------------------------------------
class ListingDetailsScreen extends StatelessWidget {
  final ListingModel listing;

  const ListingDetailsScreen({super.key, required this.listing});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(listing.title)),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _MediaSection(listing: listing),
            _DetailsSection(listing: listing),
          ],
        ),
      ),
    );
  }
}

/// ------------------------------------------------------------
/// MEDIA (IMAGES + VIDEOS)
/// ------------------------------------------------------------
class _MediaSection extends StatelessWidget {
  final ListingModel listing;

  const _MediaSection({required this.listing});

  @override
  Widget build(BuildContext context) {
    final images = listing.photos;
    final videos = listing.videos;

    if ((images.isEmpty) && (videos.isEmpty)) {
      return const SizedBox.shrink();
    }

    return SizedBox(
      height: 260,
      child: ListView(
        scrollDirection: Axis.horizontal,
        children: [
          ...images.map(
                (img) => _ImageCard(imageUrl: img),
          ),
          ...videos.map(
                (vid) => _VideoPreviewCard(videoUrl: vid),
          ),
        ],
      ),
    );
  }
}

/// ------------------------------------------------------------
/// IMAGE CARD
/// ------------------------------------------------------------
class _ImageCard extends StatelessWidget {
  final String imageUrl;

  const _ImageCard({required this.imageUrl});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => push(
        context,
        FullScreenImageViewer(imageUrl: imageUrl, imageFile: null),
      ),
      child: Container(
        width: 240,
        margin: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          image: DecorationImage(
            image: NetworkImage(imageUrl),
            fit: BoxFit.cover,
          ),
        ),
      ),
    );
  }
}

/// ------------------------------------------------------------
/// VIDEO PREVIEW CARD
/// ------------------------------------------------------------
class _VideoPreviewCard extends StatefulWidget {
  final String videoUrl;

  const _VideoPreviewCard({required this.videoUrl});

  @override
  State<_VideoPreviewCard> createState() => _VideoPreviewCardState();
}

class _VideoPreviewCardState extends State<_VideoPreviewCard> {
  late VideoPlayerController _controller;
  bool _initialized = false;

  @override
  void initState() {
    super.initState();
    _controller = VideoPlayerController.networkUrl(Uri.parse(widget.videoUrl))
      ..setLooping(true)
      ..setVolume(0)
      ..initialize().then((_) {
        if (mounted) {
          setState(() => _initialized = true);
        }
      });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _openFullscreen(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => _FullscreenVideoPlayer(url: widget.videoUrl),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return VisibilityDetector(
      key: Key(widget.videoUrl),
      onVisibilityChanged: (info) {
        if (!_initialized) return;
        if (info.visibleFraction > 0.6) {
          _controller.play();
        } else {
          _controller.pause();
        }
      },
      child: GestureDetector(
        onTap: () => _openFullscreen(context),
        child: Container(
          width: 240,
          margin: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: Colors.black,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Stack(
            alignment: Alignment.center,
            children: [
              if (_initialized)
                ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: VideoPlayer(_controller),
                )
              else
                const Center(child: CircularProgressIndicator()),
              const Icon(
                Icons.play_circle_fill,
                size: 64,
                color: Colors.white70,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// ------------------------------------------------------------
/// FULLSCREEN VIDEO (SOUND ON)
/// ------------------------------------------------------------
class _FullscreenVideoPlayer extends StatefulWidget {
  final String url;

  const _FullscreenVideoPlayer({required this.url});

  @override
  State<_FullscreenVideoPlayer> createState() => _FullscreenVideoPlayerState();
}

class _FullscreenVideoPlayerState extends State<_FullscreenVideoPlayer> {
  late VideoPlayerController _controller;

  @override
  void initState() {
    super.initState();
    _controller = VideoPlayerController.networkUrl(Uri.parse(widget.url))
      ..initialize().then((_) {
        setState(() {});
        _controller.setVolume(1);
        _controller.play();
      });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(backgroundColor: Colors.black),
      body: Center(
        child: _controller.value.isInitialized
            ? AspectRatio(
          aspectRatio: _controller.value.aspectRatio,
          child: VideoPlayer(_controller),
        )
            : const CircularProgressIndicator(),
      ),
    );
  }
}

/// ------------------------------------------------------------
/// DETAILS
/// ------------------------------------------------------------
class _DetailsSection extends StatelessWidget {
  final ListingModel listing;

  const _DetailsSection({required this.listing});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(listing.title, style: const TextStyle(fontSize: 22)),
          const SizedBox(height: 8),
          Text(listing.description),
        ],
      ),
    );
  }
}
