library geolocator_linux;

export 'src/geolocator_linux.dart';
