import 'package:instaflutter/listings/main.dart';

const finishedOnBoardingConst = 'finishedOnBoarding_listings';

/// These values are set in the [runListings] file
var appName = '';
var colorAccent = 0;
var colorPrimaryDark = 0;
var colorPrimary = 0;

var categoriesCollection = '';
var listingsCollection = '';
var reviewCollection = '';
var filtersCollection = '';

// NEW: Google Maps Places API Key (required for Place Details lookup)
var googleMapsApiKey = 'AIzaSyCHl0NG-dxRunt4ZVukmsMXX-J-aetCPbs';
