part of 'filters_bloc.dart';

abstract class FiltersEvent {}

class GetFiltersEvent extends FiltersEvent {}
