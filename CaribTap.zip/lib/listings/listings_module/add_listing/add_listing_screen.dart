import 'dart:io';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_google_places_hoc081098/flutter_google_places_hoc081098.dart';
import 'package:flutter_google_places_hoc081098/google_maps_webservice_places.dart';
import 'package:instaflutter/constants.dart';
import 'package:instaflutter/core/ui/full_screen_image_viewer/full_screen_image_viewer.dart';
import 'package:instaflutter/core/ui/loading/loading_cubit.dart';
import 'package:instaflutter/core/utils/helper.dart';
import 'package:instaflutter/listings/listings_app_config.dart';
import 'package:instaflutter/listings/model/categories_model.dart';
import 'package:instaflutter/listings/model/listing_model.dart';
import 'package:instaflutter/listings/model/listings_user.dart';
import 'package:instaflutter/listings/listings_module/add_listing/add_listing_bloc.dart';
import 'package:instaflutter/listings/listings_module/add_listing/add_listing_event.dart';
import 'package:instaflutter/listings/listings_module/add_listing/add_listing_state.dart';
import 'package:instaflutter/listings/listings_module/api/listings_api_manager.dart';
import 'package:instaflutter/listings/listings_module/filters/filters_screen.dart';

class AddListingWrappingWidget extends StatelessWidget {
  final ListingsUser currentUser;

  const AddListingWrappingWidget({super.key, required this.currentUser});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => AddListingBloc(
        currentUser: currentUser,
        listingsRepository: listingApiManager,
      ),
      child: AddListingScreen(currentUser: currentUser),
    );
  }
}

class EditListingWrappingWidget extends StatelessWidget {
  final ListingsUser currentUser;
  final ListingModel listingToEdit;

  const EditListingWrappingWidget({
    super.key,
    required this.currentUser,
    required this.listingToEdit,
  });

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => AddListingBloc(
        currentUser: currentUser,
        listingsRepository: listingApiManager,
      ),
      child: AddListingScreen(
        currentUser: currentUser,
        listingToEdit: listingToEdit,
      ),
    );
  }
}

class AddListingScreen extends StatefulWidget {
  final ListingsUser currentUser;
  final ListingModel? listingToEdit;

  const AddListingScreen({
    super.key,
    required this.currentUser,
    this.listingToEdit,
  });

  @override
  State<AddListingScreen> createState() => _AddListingScreenState();
}

class _AddListingScreenState extends State<AddListingScreen> {
  CategoriesModel? _categoryValue;

  final TextEditingController _titleController = TextEditingController();
  final TextEditingController _descController = TextEditingController();
  final TextEditingController _priceController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _websiteController = TextEditingController();
  final TextEditingController _openingHoursController = TextEditingController();

  Map<String, String>? _filters = {};
  PlaceDetails? _placeDetail;

  // Existing photo URLs (edit mode)
  final List<String> _existingPhotoUrls = [];

  // New local images picked this session (file list managed by bloc)
  List<File?> _newImages = [null];

  List<CategoriesModel> _categories = [];
  late ListingsUser currentUser;
  bool isLoadingCategories = true;

  bool get isEdit => widget.listingToEdit != null;

  @override
  void initState() {
    super.initState();
    currentUser = widget.currentUser;
    context.read<AddListingBloc>().add(GetCategoriesEvent());

    // Prefill for EDIT mode
    if (isEdit) {
      final l = widget.listingToEdit!;
      _titleController.text = l.title;
      _descController.text = l.description;
      _priceController.text = (l.price).replaceAll('\$', '').trim();
      _filters = Map<String, String>.from(l.filters ?? {});
      _existingPhotoUrls.addAll(
        List<String>.from(l.photos ?? []).where((e) => e.trim().isNotEmpty),
      );
      _phoneController.text = (l.phone ?? '').trim();
      _emailController.text = (l.email ?? '').trim();
      _websiteController.text = (l.website ?? '').trim();
      _openingHoursController.text = (l.openingHours ?? '').trim();

      // Critical: set placeDetail so validation sees a place even before user re-selects
      _placeDetail = _fakePlaceDetailsFromExisting(
        l.title,
        l.place,
        l.latitude,
        l.longitude,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return BlocListener<AddListingBloc, AddListingState>(
      listener: (listenerContext, state) async {
        if (state is AddListingErrorState) {
          context.read<LoadingCubit>().hideLoading();
          if (!mounted) return;
          showAlertDialog(listenerContext, state.errorTitle, state.errorMessage);
        } else if (state is ListingPublishedState) {
          context.read<LoadingCubit>().hideLoading();
          Navigator.pop(context);
          showAlertDialog(
            context,
            'Listing Added'.tr(),
            'Your listing has been added successfully'.tr(),
          );
        } else if (state is ListingUpdatedState) {
          context.read<LoadingCubit>().hideLoading();
          Navigator.pop(context);
          showAlertDialog(
            context,
            'Listing Updated'.tr(),
            'Your listing has been updated successfully'.tr(),
          );
        }
      },
      listenWhen: (old, current) =>
      old != current &&
          (current is AddListingErrorState ||
              current is ListingPublishedState ||
              current is ListingUpdatedState ||
              current is AddListingProgressState),
      child: Scaffold(
        resizeToAvoidBottomInset: true,
        appBar: AppBar(
          title: Text(isEdit ? 'Edit Listing'.tr() : 'Add Listing'.tr()),
        ),
        body: SingleChildScrollView(
          keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _buildTextSection('Title', _titleController),
              _buildTextSection('Description', _descController, multiline: true),

              // LOCATION (fixed)
              ListTile(
                dense: true,
                title: Text(
                  'Location'.tr(),
                  style: const TextStyle(fontSize: 20),
                ),
                trailing: SizedBox(
                  width: MediaQuery.of(context).size.width / 2,
                  child: Text(
                    _placeDetail?.formattedAddress?.toString().trim().isNotEmpty ==
                        true
                        ? _placeDetail!.formattedAddress!.toString()
                        : (isEdit
                        ? (widget.listingToEdit?.place ??
                        'Select Place'.tr())
                        : 'Select Place'.tr()),
                    textAlign: TextAlign.end,
                  ),
                ),
                onTap: () async {
                  final prediction = await PlacesAutocomplete.show(
                    context: context,
                    apiKey: googleApiKey,
                    mode: Mode.fullscreen,
                    language: 'en',
                  );

                  if (prediction == null) return;

                  // If placeId is null, do not update selection (no geometry possible)
                  final placeId = prediction.placeId;
                  if (placeId == null || placeId.trim().isEmpty) {
                    if (!mounted) return;
                    showAlertDialog(
                      context,
                      'Place Error'.tr(),
                      'The selected place did not return a placeId. Please try another result.'
                          .tr(),
                    );
                    return;
                  }

                  // Show loading while fetching details
                  context.read<LoadingCubit>().showLoading(
                    context,
                    'Loading...'.tr(),
                    false,
                    Color(colorPrimary),
                  );

                  try {
                    final places = GoogleMapsPlaces(apiKey: googleApiKey);
                    final details = await places.getDetailsByPlaceId(placeId);

                    if (!details.isOkay || details.result == null) {
                      context.read<LoadingCubit>().hideLoading();
                      if (!mounted) return;

                      showAlertDialog(
                        context,
                        'Place Error'.tr(),
                        (details.errorMessage?.isNotEmpty == true)
                            ? details.errorMessage!
                            : 'Google Places details failed. Check API key restrictions / billing / Places API enabled.'
                            .tr(),
                      );
                      return;
                    }

                    final result = details.result!;
                    final loc = result.geometry?.location;

                    // Hard requirement: geometry must exist
                    if (loc == null) {
                      context.read<LoadingCubit>().hideLoading();
                      if (!mounted) return;

                      showAlertDialog(
                        context,
                        'Place Error'.tr(),
                        'Selected place has no coordinates (geometry). Please pick another result.'
                            .tr(),
                      );
                      return;
                    }

                    if (!mounted) return;
                    setState(() {
                      _placeDetail = result;
                    });

                    context.read<LoadingCubit>().hideLoading();
                  } catch (e) {
                    context.read<LoadingCubit>().hideLoading();
                    if (!mounted) return;

                    showAlertDialog(
                      context,
                      'Place Error'.tr(),
                      'Failed to fetch place details. This is usually due to API key restrictions, billing not enabled, or Places API not enabled.'
                          .tr(),
                    );
                  }
                },
              ),

              Padding(
                padding: const EdgeInsets.symmetric(
                    vertical: 12, horizontal: 16.0),
                child: Text(
                  'Add Photos'.tr(),
                  style: const TextStyle(fontSize: 25),
                ),
              ),

              // Existing photos (edit mode)
              if (_existingPhotoUrls.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(bottom: 8.0),
                  child: SizedBox(
                    height: 100,
                    child: ListView.builder(
                      shrinkWrap: true,
                      itemCount: _existingPhotoUrls.length,
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      scrollDirection: Axis.horizontal,
                      itemBuilder: (context, index) {
                        final url = _existingPhotoUrls[index];
                        return _ExistingListingImageWidget(
                          imageUrl: url,
                          onRemove: () {
                            setState(() {
                              _existingPhotoUrls.removeAt(index);
                            });
                          },
                        );
                      },
                    ),
                  ),
                ),

              // New photos (picked now)
              BlocBuilder<AddListingBloc, AddListingState>(
                buildWhen: (old, current) =>
                old != current && current is ListingImagesUpdatedState,
                builder: (context, state) {
                  if (state is ListingImagesUpdatedState) {
                    _newImages = [...state.images, null];
                  }
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 8.0),
                    child: SizedBox(
                      height: 100,
                      child: ListView.builder(
                        shrinkWrap: true,
                        itemCount: _newImages.length,
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        scrollDirection: Axis.horizontal,
                        itemBuilder: (context, index) =>
                            ListingImageWidget(imageFile: _newImages[index]),
                      ),
                    ),
                  );
                },
              ),

              Padding(
                padding:
                const EdgeInsets.symmetric(horizontal: 16.0, vertical: 24),
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(
                        vertical: 16, horizontal: 24),
                    backgroundColor: Color(colorPrimary),
                    shape: RoundedRectangleBorder(
                      side: BorderSide.none,
                      borderRadius: BorderRadius.circular(6),
                    ),
                  ),
                  child: Text(
                    isEdit ? 'Save Changes'.tr() : 'Post Listing'.tr(),
                    style: TextStyle(
                      color: isDarkMode(context) ? Colors.black : Colors.white,
                      fontSize: 20,
                    ),
                  ),
                  onPressed: _postListing,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTextSection(String title, TextEditingController controller,
      {bool multiline = false}) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title.tr(), style: const TextStyle(fontSize: 20)),
          const SizedBox(height: 8),
          TextField(
            controller: controller,
            keyboardType: multiline ? TextInputType.multiline : null,
            maxLines: multiline ? null : 1,
            decoration: InputDecoration(
              hintText: 'Start typing'.tr(),
              isDense: true,
              enabledBorder: const UnderlineInputBorder(
                borderSide: BorderSide.none,
              ),
              focusedBorder: const UnderlineInputBorder(
                borderSide: BorderSide.none,
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _titleController.dispose();
    _descController.dispose();
    _priceController.dispose();
    _phoneController.dispose();
    _emailController.dispose();
    _websiteController.dispose();
    _openingHoursController.dispose();
    super.dispose();
  }

  void _postListing() {
    context.read<LoadingCubit>().showLoading(
      context,
      'Loading...'.tr(),
      false,
      Color(colorPrimary),
    );

    final listingToEdit = widget.listingToEdit;

    context.read<AddListingBloc>().add(
      ValidateListingInputEvent(
        title: _titleController.text.trim(),
        description: _descController.text.trim(),
        price: _priceController.text.trim(),
        phone: _phoneController.text.trim(),
        email: _emailController.text.trim(),
        website: _websiteController.text.trim(),
        openingHours: _openingHoursController.text.trim(),
        category: _categoryValue ??
            (isEdit
                ? CategoriesModel(
              id: listingToEdit!.categoryID,
              title: listingToEdit.categoryTitle,
              photo: listingToEdit.categoryPhoto,
              isActive: true,
              sortOrder: 0,
            )
                : null),
        filters: _filters,
        placeDetails: _placeDetail ??
            (isEdit
                ? _fakePlaceDetailsFromExisting(
              listingToEdit!.title,
              listingToEdit.place,
              listingToEdit.latitude,
              listingToEdit.longitude,
            )
                : null),
        isEdit: isEdit,
        listingToEdit: listingToEdit,
        existingPhotoUrls: List<String>.from(_existingPhotoUrls),
      ),
    );
  }

  // Helper to avoid forcing user to re-pick a location in Edit mode
  PlaceDetails _fakePlaceDetailsFromExisting(
      String name,
      String address,
      double lat,
      double lng,
      ) {
    final safeAddress =
    address.trim().isEmpty ? 'Unknown location'.tr() : address.trim();

    return PlaceDetails(
      placeId: 'manual_${lat.toStringAsFixed(6)}_${lng.toStringAsFixed(6)}',
      name: name.trim().isEmpty ? safeAddress : name,
      formattedAddress: safeAddress,
      geometry: Geometry(
        location: Location(lat: lat, lng: lng),
      ),
    );
  }
}

class _ExistingListingImageWidget extends StatelessWidget {
  final String imageUrl;
  final VoidCallback onRemove;

  const _ExistingListingImageWidget({
    required this.imageUrl,
    required this.onRemove,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => showCupertinoModalPopup(
        context: context,
        builder: (context) => CupertinoActionSheet(
          actions: [
            CupertinoActionSheetAction(
              onPressed: () {
                Navigator.pop(context);
                onRemove();
              },
              isDestructiveAction: true,
              child: Text('Remove Picture'.tr()),
            ),
            CupertinoActionSheetAction(
              onPressed: () {
                Navigator.pop(context);
                push(
                  context,
                  FullScreenImageViewer(imageUrl: imageUrl, imageFile: null),
                );
              },
              isDefaultAction: true,
              child: Text('View Picture'.tr()),
            ),
          ],
          cancelButton: CupertinoActionSheetAction(
            child: Text('Cancel'.tr()),
            onPressed: () => Navigator.pop(context),
          ),
        ),
      ),
      child: SizedBox(
        width: 100,
        child: Card(
          shape: RoundedRectangleBorder(
            side: BorderSide.none,
            borderRadius: BorderRadius.circular(12),
          ),
          color: Colors.black12,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: Image.network(
              imageUrl,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) =>
              const Center(child: Icon(Icons.broken_image)),
            ),
          ),
        ),
      ),
    );
  }
}

class ListingImageWidget extends StatefulWidget {
  final File? imageFile;

  const ListingImageWidget({super.key, required this.imageFile});

  @override
  State<ListingImageWidget> createState() => _ListingImageWidgetState();
}

class _ListingImageWidgetState extends State<ListingImageWidget> {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        widget.imageFile == null
            ? _pickImage(context)
            : _viewOrDeleteImage(widget.imageFile!, context);
      },
      child: SizedBox(
        width: 100,
        child: Card(
          shape: RoundedRectangleBorder(
            side: BorderSide.none,
            borderRadius: BorderRadius.circular(12),
          ),
          color: Color(colorPrimary),
          child: widget.imageFile == null
              ? Icon(
            Icons.camera_alt,
            size: 40,
            color: isDarkMode(context) ? Colors.black : Colors.white,
          )
              : ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: Image.file(
              widget.imageFile!,
              fit: BoxFit.cover,
            ),
          ),
        ),
      ),
    );
  }

  void _viewOrDeleteImage(File imageFile, BuildContext blocContext) =>
      showCupertinoModalPopup(
        context: context,
        builder: (context) => CupertinoActionSheet(
          actions: [
            CupertinoActionSheetAction(
              onPressed: () async {
                Navigator.pop(context);
                blocContext
                    .read<AddListingBloc>()
                    .add(RemoveListingImageEvent(image: imageFile));
              },
              isDestructiveAction: true,
              child: Text('Remove Picture'.tr()),
            ),
            CupertinoActionSheetAction(
              onPressed: () {
                Navigator.pop(context);
                push(
                  context,
                  FullScreenImageViewer(imageUrl: 'preview', imageFile: imageFile),
                );
              },
              isDefaultAction: true,
              child: Text('View Picture'.tr()),
            ),
          ],
          cancelButton: CupertinoActionSheetAction(
            child: Text('Cancel'.tr()),
            onPressed: () => Navigator.pop(context),
          ),
        ),
      );

  void _pickImage(BuildContext blocContext) => showCupertinoModalPopup(
    context: context,
    builder: (context) => CupertinoActionSheet(
      message: Text(
        'Add picture'.tr(),
        style: const TextStyle(fontSize: 15.0),
      ),
      actions: [
        CupertinoActionSheetAction(
          isDefaultAction: false,
          onPressed: () {
            Navigator.pop(context);
            blocContext
                .read<AddListingBloc>()
                .add(AddImageToListingEvent(fromGallery: true));
          },
          child: Text('Choose from gallery'.tr()),
        ),
        CupertinoActionSheetAction(
          isDestructiveAction: false,
          onPressed: () {
            Navigator.pop(context);
            blocContext
                .read<AddListingBloc>()
                .add(AddImageToListingEvent(fromGallery: false));
          },
          child: Text('Take a picture'.tr()),
        )
      ],
      cancelButton: CupertinoActionSheetAction(
        child: Text('Cancel'.tr()),
        onPressed: () => Navigator.pop(context),
      ),
    ),
  );
}
