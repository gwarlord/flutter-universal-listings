part of 'loading_cubit.dart';

@immutable
abstract class LoadingIndicatorState {}

class LoadingInitial extends LoadingIndicatorState {}
