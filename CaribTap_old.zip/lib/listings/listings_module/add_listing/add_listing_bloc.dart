import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_google_places_hoc081098/google_maps_webservice_places.dart';
import 'package:instaflutter/listings/model/listing_model.dart';
import 'package:instaflutter/listings/model/listings_user.dart';
import 'package:instaflutter/listings/listings_module/add_listing/add_listing_event.dart';
import 'package:instaflutter/listings/listings_module/add_listing/add_listing_state.dart';
import 'package:instaflutter/listings/listings_module/api/listings_repository.dart';

/// Caribbean + Caribbean territories (ISO 3166-1 alpha-2)
const Set<String> kCaribbeanCountryCodes = {
  'AI', // Anguilla
  'AG', // Antigua and Barbuda
  'AW', // Aruba
  'BS', // Bahamas
  'BB', // Barbados
  'BZ', // Belize
  'BM', // Bermuda
  'BQ', // Bonaire, Sint Eustatius and Saba
  'VG', // British Virgin Islands
  'KY', // Cayman Islands
  'CU', // Cuba
  'CW', // Curaçao
  'DM', // Dominica
  'DO', // Dominican Republic
  'GD', // Grenada
  'GP', // Guadeloupe
  'GY', // Guyana
  'HT', // Haiti
  'JM', // Jamaica
  'MQ', // Martinique
  'MS', // Montserrat
  'PR', // Puerto Rico
  'BL', // Saint Barthélemy
  'KN', // Saint Kitts and Nevis
  'LC', // Saint Lucia
  'MF', // Saint Martin (French part)
  'VC', // Saint Vincent and the Grenadines
  'SX', // Sint Maarten (Dutch part)
  'SR', // Suriname
  'TT', // Trinidad and Tobago
  'TC', // Turks and Caicos Islands
  'VI', // U.S. Virgin Islands
};

class AddListingBloc extends Bloc<AddListingEvent, AddListingState> {
  final ListingsUser currentUser;
  final ListingsRepository listingsRepository;

  /// New images selected during Add/Edit
  final List<File> listingImages = [];

  AddListingBloc({
    required this.currentUser,
    required this.listingsRepository,
  }) : super(AddListingInitial()) {
    on<GetCategoriesEvent>((event, emit) async {
      final categories = await listingsRepository.getCategories();
      emit(CategoriesFetchedState(categories: categories));
    });

    on<CategorySelectedEvent>((event, emit) async {
      emit(CategorySelectedState(category: event.categoriesModel));
    });

    on<SetFiltersEvent>((event, emit) async {
      emit(SetFiltersState(filters: event.filters));
    });

    on<GetPlaceDetailsEvent>((event, emit) async {
      final PlaceDetails? placeDetails =
      await listingsRepository.getPlaceDetails(event.prediction);
      emit(PlaceDetailsState(placeDetails: placeDetails));
    });

    on<AddImageToListingEvent>((event, emit) async {
      final File? image = await listingsRepository.getListingImage(
        fromGallery: event.fromGallery,
      );
      if (image != null) {
        listingImages.add(image);
        emit(ListingImagesUpdatedState(images: List<File>.from(listingImages)));
      }
    });

    on<RemoveListingImageEvent>((event, emit) async {
      // Screen manages removing existing URL images.
      // Bloc only removes NEW picked File images if passed in.
      if (event.image is File) {
        listingImages.remove(event.image as File);
        emit(ListingImagesUpdatedState(images: List<File>.from(listingImages)));
      }
    });

    on<ValidateListingInputEvent>((event, emit) {
      if (event.title.isEmpty) {
        emit(AddListingErrorState(
          errorTitle: 'Missing Title'.tr(),
          errorMessage: 'You need to set a title for the listing.'.tr(),
        ));
        return;
      }

      if (event.description.isEmpty) {
        emit(AddListingErrorState(
          errorTitle: 'Missing Description'.tr(),
          errorMessage: 'You need a short description for the listing.'.tr(),
        ));
        return;
      }

      if (event.category == null) {
        emit(AddListingErrorState(
          errorTitle: 'Missing Category'.tr(),
          errorMessage: 'You need to select a category for the listing.'.tr(),
        ));
        return;
      }

      if (event.placeDetails == null) {
        emit(AddListingErrorState(
          errorTitle: 'Missing Place'.tr(),
          errorMessage: 'You need to set a place for the listing.'.tr(),
        ));
        return;
      }

      // ✅ Caribbean-only country validation
      final String countryCode = event.countryCode.trim().toUpperCase();
      if (countryCode.isEmpty) {
        emit(AddListingErrorState(
          errorTitle: 'Missing Country'.tr(),
          errorMessage: 'Please select a country.'.tr(),
        ));
        return;
      }
      if (!kCaribbeanCountryCodes.contains(countryCode)) {
        emit(AddListingErrorState(
          errorTitle: 'Invalid Country'.tr(),
          errorMessage: 'Please choose a Caribbean country.'.tr(),
        ));
        return;
      }

      // For ADD: require at least one new image
      // For EDIT: allow either existing photos OR new photos
      final int totalPhotos =
          event.existingPhotoUrls.length + listingImages.length;
      if (totalPhotos == 0) {
        emit(AddListingErrorState(
          errorTitle: 'Missing Images'.tr(),
          errorMessage: 'You need at least one photo for the listing.'.tr(),
        ));
        return;
      }

      final model = ListingModel(
        title: event.title,
        createdAt: event.isEdit
            ? (event.listingToEdit?.createdAt ?? Timestamp.now().seconds)
            : Timestamp.now().seconds,
        authorID: event.isEdit
            ? (event.listingToEdit?.authorID ?? currentUser.userID)
            : currentUser.userID,
        authorName: event.isEdit
            ? (event.listingToEdit?.authorName ?? currentUser.fullName())
            : currentUser.fullName(),
        authorProfilePic: event.isEdit
            ? (event.listingToEdit?.authorProfilePic ??
            currentUser.profilePictureURL)
            : currentUser.profilePictureURL,
        categoryID: event.category!.id,
        categoryPhoto: event.category!.photo,
        categoryTitle: event.category!.title,
        description: event.description,
        price: event.price.trim().isEmpty ? '' : '${event.price}\$',
        latitude: event.placeDetails!.geometry!.location.lat,
        longitude: event.placeDetails!.geometry!.location.lng,
        filters: event.filters ?? {},
        place: event.placeDetails!.formattedAddress ?? '',
        phone: event.phone.trim(),
        email: event.email.trim(),
        website: event.website.trim(),
        openingHours: event.openingHours.trim(),
        reviewsCount: event.isEdit ? (event.listingToEdit?.reviewsCount ?? 0) : 0,
        reviewsSum: event.isEdit ? (event.listingToEdit?.reviewsSum ?? 0) : 0,
        isApproved:
        event.isEdit ? (event.listingToEdit?.isApproved ?? false) : false,

        // ✅ NEW: store selected Caribbean country
        countryCode: countryCode,
      );

      add(PublishListingEvent(
        listingModel: model,
        isEdit: event.isEdit,
        listingIdToUpdate: event.listingToEdit?.id,
        existingPhotoUrls: event.existingPhotoUrls,
      ));
    });

    on<PublishListingEvent>((event, emit) async {
      // Upload NEW images (if any)
      List<String> newUrls = [];
      if (listingImages.isNotEmpty) {
        emit(AddListingProgressState(progressMessage: 'Uploading Images...'.tr()));
        newUrls = await listingsRepository.uploadListingImages(images: listingImages);
        if (newUrls.isEmpty) {
          emit(AddListingErrorState(
            errorTitle: 'Upload Failed'.tr(),
            errorMessage: 'We could not upload your images. Please try again.'.tr(),
          ));
          return;
        }
      }

      final allPhotos = [...event.existingPhotoUrls, ...newUrls];
      if (allPhotos.isEmpty) {
        emit(AddListingErrorState(
          errorTitle: 'Missing Images'.tr(),
          errorMessage: 'You need at least one photo for the listing.'.tr(),
        ));
        return;
      }

      event.listingModel.photo = allPhotos.first;
      event.listingModel.photos = allPhotos;

      if (!event.isEdit) {
        emit(AddListingProgressState(progressMessage: 'Publishing Listing...'.tr()));
        final bool isDone = await listingsRepository.publishListing(event.listingModel);

        if (isDone) {
          listingImages.clear();
          emit(ListingPublishedState());
        } else {
          emit(AddListingErrorState(
            errorTitle: 'Publish Failed'.tr(),
            errorMessage: 'We could not publish your listing. Please try again.'.tr(),
          ));
        }
        return;
      }

      // EDIT: update Firestore directly (keeps your existing repository intact)
      if (event.listingIdToUpdate == null || event.listingIdToUpdate!.trim().isEmpty) {
        emit(AddListingErrorState(
          errorTitle: 'Update Failed'.tr(),
          errorMessage: 'Missing listing ID. Cannot update this listing.'.tr(),
        ));
        return;
      }

      emit(AddListingProgressState(progressMessage: 'Updating Listing...'.tr()));
      try {
        await FirebaseFirestore.instance
            .collection('listings')
            .doc(event.listingIdToUpdate)
            .update({
          'title': event.listingModel.title,
          'description': event.listingModel.description,
          'price': event.listingModel.price,
          'categoryID': event.listingModel.categoryID,
          'categoryPhoto': event.listingModel.categoryPhoto,
          'categoryTitle': event.listingModel.categoryTitle,
          'filters': event.listingModel.filters,
          'place': event.listingModel.place,
          'latitude': event.listingModel.latitude,
          'longitude': event.listingModel.longitude,
          'phone': event.listingModel.phone,
          'email': event.listingModel.email,
          'website': event.listingModel.website,
          'openingHours': event.listingModel.openingHours,
          'photo': event.listingModel.photo,
          'photos': event.listingModel.photos,

          // ✅ NEW: persist country selection on edit
          'countryCode': event.listingModel.countryCode.toUpperCase(),
        });

        listingImages.clear();
        emit(ListingUpdatedState());
      } catch (_) {
        emit(AddListingErrorState(
          errorTitle: 'Update Failed'.tr(),
          errorMessage: 'We could not update your listing. Please try again.'.tr(),
        ));
      }
    });
  }
}
