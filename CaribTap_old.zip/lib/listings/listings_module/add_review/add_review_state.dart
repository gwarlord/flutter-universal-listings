part of 'add_review_bloc.dart';

abstract class AddReviewState {}

class AddReviewInitial extends AddReviewState {}

class PostReviewSuccessState extends AddReviewState {}
