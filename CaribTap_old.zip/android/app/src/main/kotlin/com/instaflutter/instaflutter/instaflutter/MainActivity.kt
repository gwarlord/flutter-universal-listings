package com.instaflutter.instaflutter.instaflutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
